#!/bin/bash
# Yossarian Alerting - Automated Verification Script
# This script checks if your alerting setup is configured correctly

set -e

NAMESPACE_YOSSARIAN="yossarian"
NAMESPACE_MONITORING="monitoring"
RELEASE_NAME="kube-prometheus"

echo "🔍 Yossarian Alerting Verification Script"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

function check_pass() {
    echo -e "${GREEN}✓${NC} $1"
}

function check_fail() {
    echo -e "${RED}✗${NC} $1"
}

function check_warn() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Step 1: Check if namespaces exist
echo "📦 Step 1: Checking namespaces..."
if kubectl get namespace $NAMESPACE_YOSSARIAN &>/dev/null; then
    check_pass "Namespace '$NAMESPACE_YOSSARIAN' exists"
else
    check_fail "Namespace '$NAMESPACE_YOSSARIAN' not found"
    echo "   Run: kubectl create namespace $NAMESPACE_YOSSARIAN"
fi

if kubectl get namespace $NAMESPACE_MONITORING &>/dev/null; then
    check_pass "Namespace '$NAMESPACE_MONITORING' exists"
else
    check_fail "Namespace '$NAMESPACE_MONITORING' not found"
fi
echo ""

# Step 2: Check Prometheus Operator
echo "🔧 Step 2: Checking Prometheus Operator..."
if kubectl get prometheus -n $NAMESPACE_MONITORING ${RELEASE_NAME}-prometheus &>/dev/null; then
    check_pass "Prometheus instance found: ${RELEASE_NAME}-prometheus"
    
    # Check if Prometheus pod is running
    PROM_PODS=$(kubectl get pods -n $NAMESPACE_MONITORING -l app.kubernetes.io/name=prometheus -o jsonpath='{.items[*].status.phase}')
    if [[ "$PROM_PODS" == *"Running"* ]]; then
        check_pass "Prometheus pod is running"
    else
        check_fail "Prometheus pod not running (Status: $PROM_PODS)"
    fi
else
    check_fail "Prometheus instance not found"
fi
echo ""

# Step 3: Check ServiceMonitor selector
echo "🎯 Step 3: Checking ServiceMonitor selector..."
SELECTOR=$(kubectl get prometheus -n $NAMESPACE_MONITORING ${RELEASE_NAME}-prometheus -o jsonpath='{.spec.serviceMonitorSelector}')
if [[ "$SELECTOR" == "{}" ]]; then
    check_pass "Prometheus selects ALL ServiceMonitors (selector: {})"
else
    check_warn "Prometheus has specific selector: $SELECTOR"
    echo "   Ensure your ServiceMonitor has matching labels"
fi
echo ""

# Step 4: Check if ServiceMonitor exists
echo "📡 Step 4: Checking ServiceMonitor..."
if kubectl get servicemonitor yossarian-go -n $NAMESPACE_YOSSARIAN &>/dev/null; then
    check_pass "ServiceMonitor 'yossarian-go' exists"
    
    # Check labels
    SM_LABELS=$(kubectl get servicemonitor yossarian-go -n $NAMESPACE_YOSSARIAN -o jsonpath='{.metadata.labels}')
    if [[ "$SM_LABELS" == *"$RELEASE_NAME"* ]]; then
        check_pass "ServiceMonitor has correct release label"
    else
        check_warn "ServiceMonitor may be missing release label"
        echo "   Current labels: $SM_LABELS"
        echo "   Run: kubectl label servicemonitor yossarian-go -n $NAMESPACE_YOSSARIAN release=$RELEASE_NAME"
    fi
else
    check_fail "ServiceMonitor 'yossarian-go' not found"
    echo "   Run: kubectl apply -f yossarian-servicemonitor-CORRECT.yaml"
fi
echo ""

# Step 5: Check if Service exists
echo "🌐 Step 5: Checking Service..."
if kubectl get service yossarian-go -n $NAMESPACE_YOSSARIAN &>/dev/null; then
    check_pass "Service 'yossarian-go' exists"
    
    # Check if service has correct labels
    SVC_LABELS=$(kubectl get service yossarian-go -n $NAMESPACE_YOSSARIAN -o jsonpath='{.metadata.labels}')
    if [[ "$SVC_LABELS" == *"yossarian-go"* ]]; then
        check_pass "Service has correct labels"
    else
        check_warn "Service may be missing app label"
        echo "   Run: kubectl label svc yossarian-go -n $NAMESPACE_YOSSARIAN app=yossarian-go"
    fi
    
    # Check if port is named 'http'
    PORT_NAME=$(kubectl get service yossarian-go -n $NAMESPACE_YOSSARIAN -o jsonpath='{.spec.ports[0].name}')
    if [[ "$PORT_NAME" == "http" ]]; then
        check_pass "Service port is named 'http'"
    else
        check_warn "Service port name is '$PORT_NAME' (expected: 'http')"
    fi
else
    check_fail "Service 'yossarian-go' not found"
fi
echo ""

# Step 6: Check if Deployment exists
echo "🚀 Step 6: Checking Deployment..."
if kubectl get deployment yossarian-go -n $NAMESPACE_YOSSARIAN &>/dev/null; then
    check_pass "Deployment 'yossarian-go' exists"
    
    # Check if pods are running
    REPLICAS=$(kubectl get deployment yossarian-go -n $NAMESPACE_YOSSARIAN -o jsonpath='{.status.readyReplicas}')
    if [[ "$REPLICAS" -gt 0 ]]; then
        check_pass "Deployment has $REPLICAS ready pods"
    else
        check_fail "No ready pods in deployment"
    fi
else
    check_fail "Deployment 'yossarian-go' not found"
fi
echo ""

# Step 7: Test metrics endpoint
echo "📊 Step 7: Testing metrics endpoint..."
POD=$(kubectl get pods -n $NAMESPACE_YOSSARIAN -l app=yossarian-go -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
if [[ -n "$POD" ]]; then
    check_pass "Found pod: $POD"
    
    echo "   Testing /metrics endpoint..."
    if kubectl exec -n $NAMESPACE_YOSSARIAN $POD -- wget -q -O- http://localhost:8080/metrics | grep -q "yossarian"; then
        check_pass "Metrics endpoint is working and returning Yossarian metrics"
    else
        check_warn "Metrics endpoint exists but may not have Yossarian-specific metrics yet"
        echo "   Hint: Add Prometheus instrumentation to your Go code"
    fi
else
    check_warn "No pods found to test metrics endpoint"
fi
echo ""

# Step 8: Check PrometheusRule
echo "🚨 Step 8: Checking PrometheusRule..."
if kubectl get prometheusrule yossarian-alerts -n $NAMESPACE_YOSSARIAN &>/dev/null; then
    check_pass "PrometheusRule 'yossarian-alerts' exists"
    
    # Check labels
    PR_LABELS=$(kubectl get prometheusrule yossarian-alerts -n $NAMESPACE_YOSSARIAN -o jsonpath='{.metadata.labels}')
    if [[ "$PR_LABELS" == *"$RELEASE_NAME"* ]]; then
        check_pass "PrometheusRule has correct release label"
    else
        check_warn "PrometheusRule may be missing release label"
        echo "   Run: kubectl label prometheusrule yossarian-alerts -n $NAMESPACE_YOSSARIAN release=$RELEASE_NAME"
    fi
else
    check_fail "PrometheusRule 'yossarian-alerts' not found"
    echo "   Run: kubectl apply -f yossarian-prometheusrule-CORRECT.yaml"
fi
echo ""

# Step 9: Check AlertManager
echo "📬 Step 9: Checking AlertManager..."
if kubectl get alertmanager -n $NAMESPACE_MONITORING &>/dev/null; then
    check_pass "AlertManager exists"
    
    # Check if AlertManager pod is running
    AM_PODS=$(kubectl get pods -n $NAMESPACE_MONITORING -l app.kubernetes.io/name=alertmanager -o jsonpath='{.items[*].status.phase}')
    if [[ "$AM_PODS" == *"Running"* ]]; then
        check_pass "AlertManager pod is running"
    else
        check_fail "AlertManager pod not running (Status: $AM_PODS)"
    fi
else
    check_fail "AlertManager not found"
fi
echo ""

# Step 10: Port-forward instructions
echo "🔌 Step 10: Access URLs (requires port-forwarding)..."
echo ""
echo "To access Prometheus:"
echo "  kubectl port-forward -n $NAMESPACE_MONITORING svc/${RELEASE_NAME}-prometheus 9090:9090"
echo "  Open: http://localhost:9090"
echo ""
echo "To access AlertManager:"
echo "  kubectl port-forward -n $NAMESPACE_MONITORING svc/${RELEASE_NAME}-alertmanager 9093:9093"
echo "  Open: http://localhost:9093"
echo ""
echo "To access Grafana:"
echo "  kubectl port-forward -n $NAMESPACE_MONITORING svc/grafana 3000:80"
echo "  Open: http://localhost:3000"
echo "  Password: kubectl get secret -n $NAMESPACE_MONITORING grafana -o jsonpath='{.data.admin-password}' | base64 -d"
echo ""

# Summary
echo "=========================================="
echo "📋 Summary"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Fix any issues marked with ✗ or ⚠ above"
echo "2. Port-forward to Prometheus and check /targets"
echo "3. Verify your ServiceMonitor shows as UP"
echo "4. Check /alerts to see if rules are loaded"
echo "5. Test alert firing: kubectl scale deployment yossarian-go -n $NAMESPACE_YOSSARIAN --replicas=0"
echo ""
echo "For detailed troubleshooting, see DEPLOYMENT-GUIDE.md"
echo ""
