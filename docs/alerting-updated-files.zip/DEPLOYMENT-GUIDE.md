# Yossarian Alerting - Deployment Guide for Your Environment

## 🎯 Your Environment Details

```
Prometheus Operator: kube-prometheus (v0.80.1)
Grafana: grafana (v11.3.0)
Namespace: monitoring
```

---

## 📋 **Step-by-Step Deployment**

### **Step 1: Verify Current Setup**

```bash
# Check Prometheus Operator is running
kubectl get pods -n monitoring | grep prometheus

# Expected output:
# prometheus-kube-prometheus-prometheus-0   2/2   Running

# Check Grafana is running
kubectl get pods -n monitoring | grep grafana

# Check what Prometheus is looking for in ServiceMonitors
kubectl get prometheus -n monitoring kube-prometheus-prometheus -o yaml | grep -A10 serviceMonitorSelector
```

**Important:** Check the output of the last command. If you see `serviceMonitorSelector: {}`, it means Prometheus will pick up **all** ServiceMonitors in any namespace. If you see specific labels, note them down.

---

### **Step 2: Create Yossarian Namespace (if not exists)**

```bash
# Check if namespace exists
kubectl get namespace yossarian

# If not, create it
kubectl create namespace yossarian
```

---

### **Step 3: Deploy ServiceMonitor**

```bash
# Apply the ServiceMonitor
kubectl apply -f yossarian-servicemonitor-CORRECT.yaml

# Verify it was created
kubectl get servicemonitor yossarian-go -n yossarian

# Check labels are correct
kubectl get servicemonitor yossarian-go -n yossarian -o yaml | grep -A5 labels
```

**Expected output:**
```yaml
labels:
  app: yossarian-go
  release: kube-prometheus  # ✅ This MUST match your helm release
```

---

### **Step 4: Verify Metrics Endpoint**

```bash
# Check if your Yossarian pods are running
kubectl get pods -n yossarian -l app=yossarian-go

# If pods exist, test metrics endpoint
kubectl port-forward -n yossarian deployment/yossarian-go 8080:8080

# In another terminal:
curl http://localhost:8080/metrics

# Expected: Prometheus-format metrics
# HELP yossarian_http_requests_total ...
# TYPE yossarian_http_requests_total counter
```

**If you see HTML instead of metrics:**
Your application doesn't have the `/metrics` endpoint yet. You need to add Prometheus instrumentation to your Go code first. See the main guide for code examples.

---

### **Step 5: Check Prometheus is Scraping**

```bash
# Port-forward to Prometheus
kubectl port-forward -n monitoring svc/kube-prometheus-prometheus 9090:9090

# Open browser: http://localhost:9090/targets
# Search for "yossarian"
```

**Expected:**
- Target should show as **UP** (green)
- Endpoint: `http://yossarian-go.yossarian.svc:8080/metrics`

**If target is missing:**
```bash
# Check Prometheus serviceMonitorSelector
kubectl get prometheus -n monitoring -o jsonpath='{.spec.serviceMonitorSelector}'

# If it shows specific labels, add them to ServiceMonitor:
kubectl label servicemonitor yossarian-go -n yossarian <label-key>=<label-value>
```

**If target shows DOWN:**
```bash
# Check if Service exists and has correct labels
kubectl get svc yossarian-go -n yossarian -o yaml

# Service must have:
# labels:
#   app: yossarian-go
# ports:
# - name: http
#   port: 8080
```

---

### **Step 6: Deploy Alert Rules**

```bash
# Apply PrometheusRule
kubectl apply -f yossarian-prometheusrule-CORRECT.yaml

# Verify it was created
kubectl get prometheusrule yossarian-alerts -n yossarian

# Check labels
kubectl get prometheusrule yossarian-alerts -n yossarian -o yaml | grep -A5 labels
```

**Expected labels:**
```yaml
labels:
  app: yossarian-go
  prometheus: kube-prometheus-prometheus
  release: kube-prometheus
```

---

### **Step 7: Verify Rules Are Loaded in Prometheus**

```bash
# Port-forward to Prometheus (if not already)
kubectl port-forward -n monitoring svc/kube-prometheus-prometheus 9090:9090

# Open: http://localhost:9090/alerts
# You should see all Yossarian alerts listed
```

**If alerts are missing:**
```bash
# Check Prometheus ruleSelector
kubectl get prometheus -n monitoring kube-prometheus-prometheus -o jsonpath='{.spec.ruleSelector}'

# Common outputs:
# 1. {} - Selects all PrometheusRules
# 2. {"matchLabels":{"release":"kube-prometheus"}} - Needs release label

# If specific selector, add labels:
kubectl label prometheusrule yossarian-alerts -n yossarian release=kube-prometheus

# Check Prometheus logs for errors
kubectl logs -n monitoring prometheus-kube-prometheus-prometheus-0 -c prometheus | grep -i error
```

---

### **Step 8: Configure AlertManager**

```bash
# Find AlertManager secret name
kubectl get secret -n monitoring | grep alertmanager

# Common names:
# - alertmanager-kube-prometheus-alertmanager
# - kube-prometheus-alertmanager-config

# Get current config
ALERTMANAGER_SECRET="alertmanager-kube-prometheus-alertmanager"
kubectl get secret ${ALERTMANAGER_SECRET} -n monitoring -o jsonpath='{.data.alertmanager\.yaml}' | base64 -d > current-alertmanager.yaml

# Edit the file with your notification settings (see example below)
nano current-alertmanager.yaml

# Apply updated config
kubectl create secret generic ${ALERTMANAGER_SECRET} \
  --from-file=alertmanager.yaml=current-alertmanager.yaml \
  -n monitoring --dry-run=client -o yaml | kubectl apply -f -

# Restart AlertManager to pick up changes
kubectl delete pod -n monitoring -l app.kubernetes.io/name=alertmanager
```

**Minimal AlertManager config example:**
```yaml
global:
  resolve_timeout: 5m

route:
  receiver: 'slack-notifications'
  group_by: ['alertname', 'namespace']
  group_wait: 30s
  group_interval: 5m
  repeat_interval: 12h

receivers:
- name: 'slack-notifications'
  slack_configs:
  - api_url: 'https://hooks.slack.com/services/YOUR/WEBHOOK/URL'
    channel: '#alerts'
    title: '[{{ .Status }}] {{ .GroupLabels.alertname }}'
    text: '{{ range .Alerts }}{{ .Annotations.summary }}{{ end }}'
```

---

### **Step 9: Test Alert Firing**

```bash
# Trigger "YossarianDown" alert by scaling to 0
kubectl scale deployment yossarian-go -n yossarian --replicas=0

# Wait 2 minutes, then check Prometheus
# http://localhost:9090/alerts
# YossarianDown should show as FIRING (red)

# Port-forward to AlertManager
kubectl port-forward -n monitoring svc/kube-prometheus-alertmanager 9093:9093

# Check AlertManager UI
# http://localhost:9093
# You should see the alert

# Restore deployment
kubectl scale deployment yossarian-go -n yossarian --replicas=2
```

---

### **Step 10: Setup Grafana Dashboard**

```bash
# Port-forward to Grafana
kubectl port-forward -n monitoring svc/grafana 3000:80

# Get Grafana admin password
kubectl get secret -n monitoring grafana -o jsonpath="{.data.admin-password}" | base64 -d
echo

# Login to Grafana: http://localhost:3000
# User: admin
# Password: <from above command>

# Add Prometheus data source:
# 1. Configuration → Data Sources → Add data source
# 2. Select Prometheus
# 3. URL: http://kube-prometheus-prometheus.monitoring.svc:9090
# 4. Click "Save & Test"

# Import Yossarian dashboard:
# 1. Dashboards → Import
# 2. Upload yossarian-dashboard.json (from previous files)
# 3. Select Prometheus data source
# 4. Click Import
```

---

## 🔍 **Troubleshooting Decision Tree**

### **Problem: Prometheus not scraping**

```bash
# 1. Check ServiceMonitor exists
kubectl get servicemonitor yossarian-go -n yossarian

# 2. Check ServiceMonitor labels
kubectl get servicemonitor yossarian-go -n yossarian -o yaml | grep -A3 labels

# 3. Check what Prometheus expects
kubectl get prometheus -n monitoring -o jsonpath='{.spec.serviceMonitorSelector}'

# 4. If selectors don't match, add labels:
kubectl label servicemonitor yossarian-go -n yossarian release=kube-prometheus

# 5. Check Service exists and has correct selector
kubectl get svc yossarian-go -n yossarian -o yaml
```

### **Problem: Alerts not showing in Prometheus**

```bash
# 1. Check PrometheusRule exists
kubectl get prometheusrule yossarian-alerts -n yossarian

# 2. Check PrometheusRule labels
kubectl get prometheusrule yossarian-alerts -n yossarian -o yaml | grep -A3 labels

# 3. Check Prometheus ruleSelector
kubectl get prometheus -n monitoring -o jsonpath='{.spec.ruleSelector}'

# 4. Add missing labels
kubectl label prometheusrule yossarian-alerts -n yossarian release=kube-prometheus

# 5. Check Prometheus logs
kubectl logs -n monitoring prometheus-kube-prometheus-prometheus-0 -c prometheus | grep -i "rule\|error"
```

### **Problem: Notifications not sent**

```bash
# 1. Check alert is in AlertManager
kubectl port-forward -n monitoring svc/kube-prometheus-alertmanager 9093:9093
# Visit http://localhost:9093

# 2. Check AlertManager config
kubectl get secret -n monitoring alertmanager-kube-prometheus-alertmanager \
  -o jsonpath='{.data.alertmanager\.yaml}' | base64 -d

# 3. Check AlertManager logs
kubectl logs -n monitoring alertmanager-kube-prometheus-alertmanager-0 | tail -50

# 4. Test Slack webhook manually
curl -X POST https://hooks.slack.com/services/YOUR/WEBHOOK/URL \
  -H "Content-Type: application/json" \
  -d '{"text": "Test from Yossarian alerting"}'
```

---

## ✅ **Validation Checklist**

Run these checks to ensure everything is working:

- [ ] **Metrics endpoint accessible**: `curl http://yossarian-go.yossarian.svc:8080/metrics`
- [ ] **ServiceMonitor created**: `kubectl get servicemonitor yossarian-go -n yossarian`
- [ ] **Prometheus scraping**: Check `/targets` in Prometheus UI
- [ ] **PrometheusRule created**: `kubectl get prometheusrule yossarian-alerts -n yossarian`
- [ ] **Alerts loaded**: Check `/alerts` in Prometheus UI
- [ ] **AlertManager configured**: Check secret in monitoring namespace
- [ ] **Test alert fires**: Scale deployment to 0, wait 2 min, check alert
- [ ] **Notification received**: Check Slack/Email after test alert
- [ ] **Grafana dashboard**: Import and verify data displays

---

## 🎓 **Understanding Your Setup**

### **Prometheus Operator Structure**

```
Helm Release: kube-prometheus
  │
  ├─> Prometheus CRD (kube-prometheus-prometheus)
  │   ├─> serviceMonitorSelector: {release: kube-prometheus}
  │   └─> ruleSelector: {release: kube-prometheus}
  │
  ├─> AlertManager StatefulSet
  │   └─> Config: alertmanager-kube-prometheus-alertmanager secret
  │
  └─> ServiceMonitors & PrometheusRules (must have matching labels)
```

### **Label Requirements**

All ServiceMonitors and PrometheusRules must have:
```yaml
labels:
  release: kube-prometheus  # Matches helm release
```

### **Namespace Strategy**

- **Prometheus Operator**: Installed in `monitoring` namespace
- **Yossarian Resources**: In `yossarian` namespace
- **Cross-namespace scraping**: Enabled by default in kube-prometheus

---

## 🚀 **Next Steps**

1. **Customize alert thresholds** based on your actual traffic patterns
2. **Add runbook URLs** for your team's documentation
3. **Configure your Slack webhook** in AlertManager config
4. **Set up Grafana contact points** for additional alerting
5. **Document escalation paths** for critical alerts
6. **Schedule regular alert testing** (quarterly recommended)

---

## 📚 **Additional Resources**

- **kube-prometheus docs**: https://github.com/prometheus-operator/kube-prometheus
- **Prometheus Operator API**: https://prometheus-operator.dev/docs/api-reference/
- **Grafana Alerting**: https://grafana.com/docs/grafana/latest/alerting/

---

**🎉 You're ready to monitor Yossarian Go! Need help? Check the troubleshooting section or ask!**
